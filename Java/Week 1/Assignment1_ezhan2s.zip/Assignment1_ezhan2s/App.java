public class App {
    public static void main(String[] args) {
        //print company info
        System.out.println("Company Name: Greenest Grass");
        System.out.println("CEO: Evan Zhang");
        System.out.println("Founded on 7/25/2023");
    }
}
